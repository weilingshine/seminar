header = '<header>\
    <div class="container">\
        <div class="mob-header">\
            <a href="javascript:;" class="slidebar-btn" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample"><span></span></a>\
            <a class="brand-logo" href="https://www.1111.com.tw/" title="1111 科技專區" target="_blank"><img src="http://192.168.1.234/event22/design/seminar/images/logo01.png"></a>\
        </div>\
        <div class="sidebar-slide collapse collapse-horizontal" id="collapseWidthExample">\
            <ul class="nav">\
                <li class="nav-item"><a href="http://192.168.1.234/event22/design/seminar/index.html" class="nav-link">首頁</a></li>\
                <li class="nav-item">\
                    <a href="javascript:;" class="nav-link">論壇講座</a>\
                    <div class="dropdown-menu">\
                        <ul class="inner">\
                            <li><a href="http://192.168.1.234/event22/design/seminar/forum/20221220/introduce.html">12/20&ensp;科技女力崛起論壇</a></li>\
                            <li><a href="http://192.168.1.234/event22/design/seminar/forum/20221123/introduce.html">11/23&ensp;南部轉型留才論壇</a></li>\
                        </ul>\
                    </div>\
                </li>\
                <li class="nav-item"><a href="https://www.technice.com.tw/tag/%e7%bc%ba%e5%b7%a5/" class="nav-link" target="_blank">相關報導</a></li>\
                <li class="nav-item"><a href="http://192.168.1.234/event22/design/seminar/talents.html" class="nav-link">新秀人才</a></li>\
                <!-- <li class="nav-item"><a href="https://www.technice.com.tw/" class="nav-link" target="_blank">科技新知</a></li> -->\
                <!-- <li class="nav-item"><a href="javascript:;" class="nav-link" data-bs-toggle="modal" data-bs-target="#exampleModal">駐站專家</a></li> -->\
                <li class="nav-item"><a href="http://192.168.1.234/event22/design/seminar/index.html#special-corp" class="nav-link">精選企業</a></li>\
                <li class="nav-item"><a href="http://192.168.1.234/event22/design/seminar/about-us.html" class="nav-link">關於我們</a></li>\
                <!-- <li><a href="javascript:;" class="search"><img src="images/icon_search.svg"></a></li> -->\
            </ul>\
        </div>\
    </div>\
</header>\
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">\
    <div class="modal-dialog">\
        <div class="modal-content">\
            <div class="modal-header">\
                <a class="btn-close" data-bs-dismiss="modal" aria-label="Close"><img src="images/close.svg"></a>\
            </div>\
            <div class="modal-body text-center">\
                <img src="http://192.168.1.234/event22/design/seminar/images/robot_01 1.jpg">\
                <p>網站建置中，敬請期待...</p>\
            </div>\
        </div>\
    </div>\
</div>';
document.write(header);