footer = '<footer>\
    <div class="container">\
        <div class="foot-info">\
            <span class="copyright">copyright © 2022 - 2023 產業人才荒論壇</span>\
        </div>\
        <ul class="foot-link">\
            <li><a href="http://192.168.1.234/event22/design/seminar/about-us.html">關於我們</a></li>\
            <li><a href="https://www.1111.com.tw/help/privacy.asp" target="_blank">隱私政策</a></li>\
            <li><a href="https://www.1111.com.tw/help/memberRead.asp" target="_blank">會員服務條款</a></li>\
            <!-- <li><a href="#">訂閱電子報</a></li> -->\
            <li><a href="https://www.facebook.com/technicenews/" class="link-social" target="_blank"><img src="http://192.168.1.234/event22/design/seminar/images/icon_facebook.svg">Facebook</a></li>\
        </ul>\
    </div>\
</footer>';
document.write(footer);