newstarsBN = '<article class="newStars-banner">\
    <div class="container">\
        <nav>\
            <ul class="breadcrumb">\
                <li class="breadcrumb-item"><a href="http://192.168.1.234/event22/design/seminar/index.html">首頁</a></li>\
                <li class="breadcrumb-item active">新秀人才</li>\
            </ul>\
        </nav>\
        <div class="slogan">\
            <h1><b>新秀</b>人才</h1>\
            <p>1111與各大培訓機構<br>提供你想要的<span>1流人才</span></p>\
        </div>\
    </div>\
</article>\
<div class="float-btn-block"><a href="https://recruit.1111.com.tw/dContactus.aspx?qa=9" target="_blank">\
    <img src="http://192.168.1.234/event22/design/seminar/images/techNewStars/icon-talent.svg"><span>聯絡人才</span></a>\
</div>';
document.write(newstarsBN);